
$(document).on("change", "#submit_request_form_check_input_field", function () {
    if ($("#submit_request_form_check_input_field").prop("checked")) {
        $(this).parent().toggleClass("active");
    }
});



$(document).on("click", "#open_add_phone_number_popup", function () {
    $(".add_phone_number_popup_general").addClass("open");
    $("body").addClass("hidden_body");
})
$(document).on("click", "#open_add_phone_number_verification_code_popup", function () {
    $(".add_phone_number_popup_general").removeClass("open");
    $(".add_phone_number_verification_code_popup").addClass("open");
    $("body").addClass("hidden_body");
})
$(document).on("click", "#open_add_phone_number_success_popup", function () {
    $(".add_phone_number_popup_general").removeClass("open");
    $(".add_phone_number_verification_code_popup").removeClass("open");
    $(".add_phone_number_success_popup").addClass("open");
    $("body").addClass("hidden_body");
})


$(document).on("click", ".add_phone_number_popup_general_close", function () {
    $(".add_phone_number_popup_general").removeClass("open");
    $("body").removeClass("hidden_body");
})
$(document).on("click", ".add_phone_number_verification_code_popup_close", function () {
    $(".add_phone_number_verification_code_popup").removeClass("open");
    $(".add_phone_number_popup_general").removeClass("open");
    $("body").removeClass("hidden_body");
})
$(document).on("click", ".add_phone_number_success_popup_close", function () {
    $(".add_phone_number_success_popup").removeClass("open");
    $(".add_phone_number_verification_code_popup").removeClass("open");
    $(".add_phone_number_popup_general").removeClass("open");
    $("body").removeClass("hidden_body");
})
$(document).on("click", ".add_phone_number_popup_close_btn", function () {
    $(".add_phone_number_success_popup").removeClass("open");
    $(".add_phone_number_verification_code_popup").removeClass("open");
    $(".add_phone_number_popup_general").removeClass("open");
    $("body").removeClass("hidden_body");
})



$(document).on("click", "#open_add_email_popup", function () {
    $(".add_email_popup_general").addClass("open");
    $("body").addClass("hidden_body");
})
$(document).on("click", "#open_add_email_verification_code_popup", function () {
    $(".add_email_popup_general").removeClass("open");
    $(".add_email_verification_code_popup").addClass("open");
    $("body").addClass("hidden_body");
})
$(document).on("click", "#open_add_email_success_popup", function () {
    $(".add_email_popup_general").removeClass("open");
    $(".add_email_verification_code_popup").removeClass("open");
    $(".add_email_success_popup").addClass("open");
    $("body").addClass("hidden_body");
})


$(document).on("click", ".add_email_popup_general_close", function () {
    $(".add_email_popup_general").removeClass("open");
    $("body").removeClass("hidden_body");
})
$(document).on("click", ".add_email_verification_code_popup_close", function () {
    $(".add_email_verification_code_popup").removeClass("open");
    $(".add_email_popup_general").removeClass("open");
    $("body").removeClass("hidden_body");
})
$(document).on("click", ".add_email_success_popup_close", function () {
    $(".add_email_success_popup").removeClass("open");
    $(".add_email_verification_code_popup").removeClass("open");
    $(".add_email_popup_general").removeClass("open");
    $("body").removeClass("hidden_body");
})
$(document).on("click", ".add_email_popup_close_btn", function () {
    $(".add_email_success_popup").removeClass("open");
    $(".add_email_verification_code_popup").removeClass("open");
    $(".add_email_popup_general").removeClass("open");
    $("body").removeClass("hidden_body");
})


$(document).on("click", "#edit_phone_btn", function () {
    $(".edit_phone_number_popup_general").addClass("open");
    $("body").addClass("hidden_body");
})

$(document).on("click", ".edit_phone_number_popup_general_close", function () {
    $(".edit_phone_number_popup_general").removeClass("open");
    $("body").removeClass("hidden_body");
})
$(document).on("click", ".edit_phone_number_verification_code_popup_close", function () {
    $(".edit_phone_number_verification_code_popup").removeClass("open");
    $(".edit_phone_number_popup_general").removeClass("open");
    $("body").removeClass("hidden_body");
})
$(document).on("click", ".edit_phone_number_success_popup_close", function () {
    $(".edit_phone_number_success_popup").removeClass("open");
    $(".edit_phone_number_verification_code_popup").removeClass("open");
    $(".edit_phone_number_popup_general").removeClass("open");
    $("body").removeClass("hidden_body");
})
$(document).on("click", ".edit_phone_number_popup_close_btn", function () {
    $(".edit_phone_number_success_popup").removeClass("open");
    $(".edit_phone_number_verification_code_popup").removeClass("open");
    $(".edit_phone_number_popup_general").removeClass("open");
    $("body").removeClass("hidden_body");
})


$(document).on("click", "#open_edit_phone_number_verification_code_popup", function () {
    $(".edit_phone_number_popup_general").removeClass("open");
    $(".edit_phone_number_verification_code_popup").addClass("open");
    $("body").addClass("hidden_body");
})
$(document).on("click", "#open_edit_phone_number_success_popup", function () {
    $(".edit_phone_number_popup_general").removeClass("open");
    $(".edit_phone_number_verification_code_popup").removeClass("open");
    $(".edit_phone_number_success_popup").addClass("open");
    $("body").addClass("hidden_body");
})




$(document).on("click", "#edit_email_btn", function () {
    $(".edit_email_popup_general").addClass("open");
    $("body").addClass("hidden_body");
})



$(document).on("click", "#open_edit_email_verification_code_popup", function () {
    $(".edit_email_popup_general").removeClass("open");
    $(".edit_email_verification_code_popup").addClass("open");
    $("body").addClass("hidden_body");
})
$(document).on("click", "#open_edit_email_success_popup", function () {
    $(".edit_email_verification_code_popup").removeClass("open");
    $(".edit_email_popup_general").removeClass("open");
    $(".edit_email_success_popup").addClass("open");
    $("body").addClass("hidden_body");
})


$(document).on("click", ".edit_email_popup_general_close", function () {
    $(".edit_email_popup_general").removeClass("open");
    $("body").removeClass("hidden_body");
})

$(document).on("click", ".edit_email_verification_code_popup_close", function () {
    $(".edit_email_verification_code_popup").removeClass("open");
    $(".edit_email_popup_general").removeClass("open");
    $("body").removeClass("hidden_body");
})

$(document).on("click", ".edit_email_success_popup_close", function () {
    $(".edit_email_success_popup").removeClass("open");
    $(".edit_email_verification_code_popup").removeClass("open");
    $(".edit_email_popup_general").removeClass("open");
    $("body").removeClass("hidden_body");
})

$(document).on("click", ".edit_email_popup_close_btn", function () {
    $(".edit_email_success_popup").removeClass("open");
    $(".edit_email_verification_code_popup").removeClass("open");
    $(".edit_email_popup_general").removeClass("open");
    $("body").removeClass("hidden_body");
})


$(document).on("click", "#edit_password_btn", function () {
    $(".edit_password_popup_general").addClass("open");
    $("body").addClass("hidden_body");
})


$(document).on("click", ".edit_password_popup_general_close", function () {
    $(".edit_password_popup_general").removeClass("open");
    $("body").removeClass("hidden_body");
})

$(document).on("click", "#edit_username_btn", function () {
    $(".edit_username_popup_general").addClass("open");
    $("body").addClass("hidden_body");
})
$(document).on("click", ".edit_username_popup_confirm_btn", function () {
    $(".edit_username_popup_general").removeClass("open");
    $(".edit_username_success_popup").addClass("open");
    $("body").addClass("hidden_body");
})


$(document).on("click", ".edit_username_popup_general_close", function () {
    $(".edit_username_popup_general").removeClass("open");
    $("body").removeClass("hidden_body");
})
$(document).on("click", ".edit_username_success_popup_close", function () {
    $(".edit_username_success_popup").removeClass("open");
    $(".edit_username_popup_general").removeClass("open");
    $("body").removeClass("hidden_body");
})
$(document).on("click", ".edit_username_success_popup_close_btn", function () {
    $(".edit_username_success_popup").removeClass("open");
    $(".edit_username_popup_general").removeClass("open");
    $("body").removeClass("hidden_body");
})


$(document).on("click", ".delete_hide_profile_btn", function () {
    $(".delete_hide_account_popup_general").addClass("open");
    $("body").addClass("hidden_body");
})
$(document).on("click", ".hide_account_popup_btn", function () {
    $(".delete_hide_account_popup_general").removeClass("open");
    $(".hide_account_popup").addClass("open");
    $("body").addClass("hidden_body");
})
$(document).on("click", ".delete_account_popup_btn", function () {
    $(".delete_hide_account_popup_general").removeClass("open");
    $(".delete_account_popup").addClass("open");
    $("body").addClass("hidden_body");
})
$(document).on("click", ".confirm_to_delete_account_popup_btn", function () {
    $(".delete_account_popup").removeClass("open");
    $(".delete_hide_account_popup_general").removeClass("open");
    $(".delete_account_password_popup").addClass("open");
    $("body").addClass("hidden_body");
})
$(document).on("click", ".delete_account_popup_general_close", function () {
    $(".delete_account_popup").removeClass("open");
    $(".delete_hide_account_popup_general").removeClass("open");
    $("body").removeClass("hidden_body");
})
$(document).on("click", ".cancel_to_delete_account_popup_btn", function () {
    $(".delete_account_popup").removeClass("open");
    $(".delete_hide_account_popup_general").removeClass("open");
    $("body").removeClass("hidden_body");
})


$(document).on("click", ".delete_hide_account_popup_general_close", function () {
    $(".delete_hide_account_popup_general").removeClass("open");
    $("body").removeClass("hidden_body");
})
$(document).on("click", ".hide_account_password_popup_close", function () {
    $(".hide_account_password_popup").removeClass("open");
    $(".delete_hide_account_popup_general").removeClass("open");
    $(".hide_account_popup").removeClass("open");
    $("body").removeClass("hidden_body");
})
$(document).on("click", ".hide_account_success_popup_close", function () {
    $(".hide_account_success_popup").removeClass("open");
    $(".hide_account_password_popup").removeClass("open");
    $(".delete_hide_account_popup_general").removeClass("open");
    $(".hide_account_popup").removeClass("open");
    $("body").removeClass("hidden_body");
})

$(document).on("click", ".confirm_to_hide_account_popup_btn", function () {
    $(".hide_account_popup").removeClass("open");
    $(".delete_hide_account_popup_general").removeClass("open");
    $(".hide_account_password_popup").addClass("open");
    $("body").addClass("hidden_body");
})
$(document).on("click", ".confirm_delete_account_password_popup_btn", function () {
    $(".delete_hide_account_popup_general").removeClass("open");
    $(".delete_account_popup").removeClass("open");
    $(".delete_account_password_popup").removeClass("open");
    $(".delete_account_success_popup").addClass("open");
    $("body").addClass("hidden_body");
})
$(document).on("click", ".edit_password_popup_confirm_btn", function () {
    $(".edit_password_popup_general").removeClass("open");
    $(".edit_password_success_popup").addClass("open");
    $("body").addClass("hidden_body");
})
$(document).on("click", ".edit_password_success_popup_close", function () {
    $(".edit_password_success_popup").removeClass("open");
    $(".edit_password_popup_general").removeClass("open");
    $("body").removeClass("hidden_body");
})
$(document).on("click", ".edit_password_success_popup_close_btn", function () {
    $(".edit_password_success_popup").removeClass("open");
    $(".edit_password_popup_general").removeClass("open");
    $("body").removeClass("hidden_body");
})




$(document).on("click", ".delete_account_password_popup_close", function () {
    $(".delete_account_password_popup").removeClass("open");
    $(".delete_hide_account_popup_general").removeClass("open");
    $(".delete_account_popup").removeClass("open");
    $("body").removeClass("hidden_body");
})
$(document).on("click", ".delete_account_success_popup_close", function () {
    $(".delete_account_success_popup").removeClass("open");
    $(".delete_account_password_popup").removeClass("open");
    $(".delete_hide_account_popup_general").removeClass("open");
    $(".delete_account_popup").removeClass("open");
    $("body").removeClass("hidden_body");
})
$(document).on("click", ".confirm_hide_account_password_popup_btn", function () {
    $(".hide_account_password_popup").removeClass("open");
    $(".delete_hide_account_popup_general").removeClass("open");
    $(".hide_account_popup").removeClass("open");
    $(".hide_account_success_popup").addClass("open");
    $("body").addClass("hidden_body");
})



$(document).on("click", ".hide_account_popup_general_close", function () {
    $(".hide_account_popup").removeClass("open");
    $(".delete_hide_account_popup_general").removeClass("open");
    $("body").removeClass("hidden_body");
})
$(document).on("click", ".cancel_to_hide_account_popup_btn", function () {
    $(".hide_account_popup").removeClass("open");
    $(".delete_hide_account_popup_general").removeClass("open");
    $("body").removeClass("hidden_body");
})


$(document).on("click", ".hamburger_menu", function () {
    $(".header_menu_popup").addClass("open");
    $("body").addClass("hidden_body");
})
$(document).on("click", ".header_menu_popup_close", function () {
    $(".header_menu_popup").removeClass("open");
    $("body").removeClass("hidden_body");
})


$('body').click(function (event)
{
    if($(event.target).closest('.add_phone_number_popup_general').length && $(event.target).is('.add_phone_number_popup_general')) {
        $(".add_phone_number_popup_general").removeClass("open");
        $("body").removeClass("hidden_body");
    }
    if($(event.target).closest('.add_phone_number_verification_code_popup').length && $(event.target).is('.add_phone_number_verification_code_popup')) {
        $(".add_phone_number_verification_code_popup").removeClass("open");
        $("body").removeClass("hidden_body");
    }
    if($(event.target).closest('.add_phone_number_success_popup').length && $(event.target).is('.add_phone_number_success_popup')) {
        $(".add_phone_number_success_popup").removeClass("open");
        $("body").removeClass("hidden_body");
    }

    if($(event.target).closest('.edit_phone_number_popup_general').length && $(event.target).is('.edit_phone_number_popup_general')) {
        $(".edit_phone_number_popup_general").removeClass("open");
        $("body").removeClass("hidden_body");
    }

    if($(event.target).closest('.edit_phone_number_verification_code_popup').length && $(event.target).is('.edit_phone_number_verification_code_popup')) {
        $(".edit_phone_number_verification_code_popup").removeClass("open");
        $("body").removeClass("hidden_body");
    }

    if($(event.target).closest('.edit_phone_number_success_popup').length && $(event.target).is('.edit_phone_number_success_popup')) {
        $(".edit_phone_number_success_popup").removeClass("open");
        $("body").removeClass("hidden_body");
    }

    if($(event.target).closest('.add_email_popup_general').length && $(event.target).is('.add_email_popup_general')) {
        $(".add_email_popup_general").removeClass("open");
        $("body").removeClass("hidden_body");
    }

    if($(event.target).closest('.add_email_verification_code_popup').length && $(event.target).is('.add_email_verification_code_popup')) {
        $(".add_email_verification_code_popup").removeClass("open");
        $("body").removeClass("hidden_body");
    }

    if($(event.target).closest('.add_email_success_popup').length && $(event.target).is('.add_email_success_popup')) {
        $(".add_email_success_popup").removeClass("open");
        $("body").removeClass("hidden_body");
    }

    if($(event.target).closest('.edit_email_popup_general').length && $(event.target).is('.edit_email_popup_general')) {
        $(".edit_email_popup_general").removeClass("open");
        $("body").removeClass("hidden_body");
    }

    if($(event.target).closest('.edit_email_verification_code_popup').length && $(event.target).is('.edit_email_verification_code_popup')) {
        $(".edit_email_verification_code_popup").removeClass("open");
        $("body").removeClass("hidden_body");
    }

    if($(event.target).closest('.edit_email_success_popup').length && $(event.target).is('.edit_email_success_popup')) {
        $(".edit_email_success_popup").removeClass("open");
        $("body").removeClass("hidden_body");
    }

    if($(event.target).closest('.edit_password_popup_general').length && $(event.target).is('.edit_password_popup_general')) {
        $(".edit_password_popup_general").removeClass("open");
        $("body").removeClass("hidden_body");
    }

    if($(event.target).closest('.edit_password_success_popup').length && $(event.target).is('.edit_password_success_popup')) {
        $(".edit_password_success_popup").removeClass("open");
        $("body").removeClass("hidden_body");
    }

    if($(event.target).closest('.edit_username_popup_general').length && $(event.target).is('.edit_username_popup_general')) {
        $(".edit_username_popup_general").removeClass("open");
        $("body").removeClass("hidden_body");
    }

    if($(event.target).closest('.edit_username_success_popup').length && $(event.target).is('.edit_username_success_popup')) {
        $(".edit_username_success_popup").removeClass("open");
        $("body").removeClass("hidden_body");
    }

    if($(event.target).closest('.delete_hide_account_popup_general').length && $(event.target).is('.delete_hide_account_popup_general')) {
        $(".delete_hide_account_popup_general").removeClass("open");
        $("body").removeClass("hidden_body");
    }

    if($(event.target).closest('.hide_account_popup').length && $(event.target).is('.hide_account_popup')) {
        $(".hide_account_popup").removeClass("open");
        $("body").removeClass("hidden_body");
    }

    if($(event.target).closest('.hide_account_password_popup').length && $(event.target).is('.hide_account_password_popup')) {
        $(".hide_account_password_popup").removeClass("open");
        $("body").removeClass("hidden_body");
    }

    if($(event.target).closest('.hide_account_success_popup').length && $(event.target).is('.hide_account_success_popup')) {
        $(".hide_account_success_popup").removeClass("open");
        $("body").removeClass("hidden_body");
    }

    if($(event.target).closest('.delete_account_popup').length && $(event.target).is('.delete_account_popup')) {
        $(".delete_account_popup").removeClass("open");
        $("body").removeClass("hidden_body");
    }

    if($(event.target).closest('.delete_account_password_popup').length && $(event.target).is('.delete_account_password_popup')) {
        $(".delete_account_password_popup").removeClass("open");
        $("body").removeClass("hidden_body");
    }
    if($(event.target).closest('.delete_account_success_popup').length && $(event.target).is('.delete_account_success_popup')) {
        $(".delete_account_success_popup").removeClass("open");
        $("body").removeClass("hidden_body");
    }
    if($(event.target).closest('.header_menu_popup').length && $(event.target).is('.header_menu_popup')) {
        $(".header_menu_popup").removeClass("open");
        $("body").removeClass("hidden_body");
    }


      if($(event.target).closest('.service_purchase_general_popup').length && $(event.target).is('.service_purchase_general_popup')) {
        $(".service_purchase_general_popup").removeClass("open");
        $("body").removeClass("hidden_body");
    }

        if($(event.target).closest('.service_purchase_insufficient_funds_popup').length && $(event.target).is('.service_purchase_insufficient_funds_popup')) {
        $(".service_purchase_insufficient_funds_popup").removeClass("open");
        $("body").removeClass("hidden_body");
    }

    if($(event.target).closest('.service_purchase_success_popup').length && $(event.target).is('.service_purchase_success_popup')) {
        $(".service_purchase_success_popup").removeClass("open");
        $("body").removeClass("hidden_body");
    }






});

$(document).on("click", ".services_item_line_icon_wrapper", function () {
    $(this).parent('.services_item').find(".services_item_hidden_info_wrapper").toggleClass("open");
    $(this).parent('.services_item').find(".services_item_line_icon_wrapper").toggleClass("active");
  
})




/*services popups*/

$(document).on("click", ".services_item_buy_btn", function () {
    $(".service_purchase_general_popup").addClass("open");
    $("body").addClass("hidden_body");
})

$(document).on("click", ".service_purchase_general_popup_close", function () {
    $(".service_purchase_general_popup").removeClass("open");
    $("body").removeClass("hidden_body");
})

$(document).on("click", ".cancel_service_purchase_popup_btn", function () {
    $(".service_purchase_general_popup").removeClass("open");
    $("body").removeClass("hidden_body");
})

$(document).on("click", ".confirm_service_purchase_popup_btn", function () {
    $(".service_purchase_general_popup").removeClass("open");
    $(".service_purchase_insufficient_funds_popup").addClass("open");
    $("body").addClass("hidden_body");
})

$(document).on("click", ".top_up_service_purchase_popup_btn", function () {
    $(".service_purchase_insufficient_funds_popup").removeClass("open");
    $(".service_purchase_general_popup_close").removeClass("open");
    $(".service_purchase_success_popup").addClass("open");
    $("body").addClass("hidden_body");
})

$(document).on("click", ".service_purchase_success_popup_close", function () {
    $(".service_purchase_success_popup").removeClass("open");
    $(".service_purchase_insufficient_funds_popup").removeClass("open");
    $(".service_purchase_general_popup_close").removeClass("open");

    $("body").removeClass("hidden_body");
})




$(document).on("click", ".cancel_service_purchase_insufficient_funds_popup_btn", function () {
    $(".service_purchase_general_popup").removeClass("open");
    $(".service_purchase_insufficient_funds_popup").removeClass("open");
    $("body").removeClass("hidden_body");
})



$(document).on("click", ".service_purchase_insufficient_funds_popup_close", function () {
    $(".service_purchase_general_popup").removeClass("open");
    $(".service_purchase_insufficient_funds_popup").removeClass("open");
    $("body").removeClass("hidden_body");
})

