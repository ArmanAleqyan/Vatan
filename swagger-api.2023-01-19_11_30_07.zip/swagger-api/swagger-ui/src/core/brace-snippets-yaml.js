/* global ace */
ace.define("ace/snippets/yaml",
  ["require","exports","module"], function(e,t,n){ // eslint-disable-line no-unused-vars
    t.snippetText=undefined
    t.scope="yaml"
  })
